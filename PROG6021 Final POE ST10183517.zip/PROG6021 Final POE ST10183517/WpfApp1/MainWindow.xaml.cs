﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RecipeApp
{
    public partial class MainWindow : Window
    {
        private RecipeManager recipeManager;

        public MainWindow()
        {
            InitializeComponent();
            recipeManager = new RecipeManager();
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            AddRecipeWindow addRecipeWindow = new AddRecipeWindow();
            if (addRecipeWindow.ShowDialog() == true)
            {
                recipeManager.AddRecipe(addRecipeWindow.Recipe);
            }
        }

        private void DisplayRecipes_Click(object sender, RoutedEventArgs e)
        {
            recipeListBox.ItemsSource = recipeManager.GetRecipes();
        }
    }

    public class AddRecipeWindow : Window
    {
        private TextBox nameTextBox;
        private ListBox ingredientListBox;
        private ListBox stepListBox;
        private Recipe recipe;

        public Recipe Recipe => recipe;

        public AddRecipeWindow()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            // Create the necessary controls for entering recipe details using XAML or code-behind

            // For simplicity, you can use TextBox, ListBox, and Button controls

            // Add event handlers and set up the layout for the window
        }

        // Implement event handlers and logic for adding a recipe
        // Retrieve the entered details and create a new Recipe object
        // Set the Recipe property and close the window
    }

    // Implement the Recipe and RecipeManager classes as per the given code
}
 class Recipe
{
    public string Name { get; set; }
    public List<Ingredient> Ingredients { get; set; }
    public List<string> Steps { get; set; }

    public Recipe()
    {
        Ingredients = new List<Ingredient>();
        Steps = new List<string>();
    }

    public double GetTotalCalories()
    {
        double totalCalories = 0;
        foreach (var ingredient in Ingredients)
        {
            totalCalories += ingredient.Calories;
        }
        return totalCalories;
    }
}

class Ingredient
{
    public string Name { get; set; }
    public double Quantity { get; set; }
    public string Unit { get; set; }
    public double Calories { get; set; }
    public string FoodGroup { get; set; }
}

class RecipeManager
{
    private List<Recipe> recipes;

    public RecipeManager() => recipes = new List<Recipe>();

    public void AddRecipe()
    {
        Recipe recipe = new Recipe();

        Console.WriteLine("Enter recipe name:");
        recipe.Name = Console.ReadLine();

        Console.WriteLine("Enter the number of ingredients:");
        int ingredientCount = Convert.ToInt32(Console.ReadLine());

        for (int i = 0; i < ingredientCount; i++)
        {
            Ingredient ingredient = new Ingredient();

            Console.WriteLine($"Enter the name of ingredient #{i + 1}:");
            ingredient.Name = Console.ReadLine();

            Console.WriteLine($"Enter the quantity of ingredient #{i + 1}:");
            ingredient.Quantity = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine($"Enter the unit of measurement for ingredient #{i + 1}:");
            ingredient.Unit = Console.ReadLine();

            Console.WriteLine($"Enter the calories for ingredient #{i + 1}:");
            ingredient.Calories = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine($"Enter the food group for ingredient #{i + 1}:");
            ingredient.FoodGroup = Console.ReadLine();

            recipe.Ingredients.Add(ingredient);
        }

        Console.WriteLine("Enter the number of steps:");
        int stepCount = Convert.ToInt32(Console.ReadLine());

        for (int i = 0; i < stepCount; i++)
        {
            Console.WriteLine($"Enter step #{i + 1}:");
            string step = Console.ReadLine();
            recipe.Steps.Add(step);
        }

        recipes.Add(recipe);
    }

    public void DisplayRecipes()
    {
        foreach (var recipe in recipes)
        {
            Console.WriteLine("Recipe: " + recipe.Name);
            Console.WriteLine("Ingredients:");

            foreach (var ingredient in recipe.Ingredients)
            {
                Console.WriteLine($"{ingredient.Name}: {ingredient.Quantity} {ingredient.Unit}");
            }

            Console.WriteLine("Steps:");
            foreach (var step in recipe.Steps)
            {
                Console.WriteLine(step);
            }

            Console.WriteLine("Total Calories: " + recipe.GetTotalCalories());

            Console.WriteLine();
        }
    }

    public override bool Equals(object obj)
    {
        return base.Equals(obj);
    }

    public override int GetHashCode()
    {
        return base.GetHashCode();
    }

    public override string ToString()
    {
        return base.ToString();
    }

    internal IEnumerable GetRecipes()
    {
        throw new NotImplementedException();
    }

    // Implement other functionalities as per requirements
}

class Program
{
    static void Main()
    {
        RecipeManager recipeManager = new RecipeManager();

        while (true)
        {
            Console.WriteLine("1. Add Recipe");
            Console.WriteLine("2. Display Recipes");
            Console.WriteLine("3. Exit");
            Console.WriteLine("Enter your choice:");

            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    recipeManager.AddRecipe();
                    break;
                case 2:
                    recipeManager.DisplayRecipes();
                    break;
                case 3:
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid choice!");
                    break;
            }
        }
    }
}